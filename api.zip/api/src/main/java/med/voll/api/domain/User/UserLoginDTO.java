package med.voll.api.domain.User;

public record UserLoginDTO(String login, String password) {
	}
