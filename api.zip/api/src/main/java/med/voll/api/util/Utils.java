package med.voll.api.util;

public class Utils {

}
