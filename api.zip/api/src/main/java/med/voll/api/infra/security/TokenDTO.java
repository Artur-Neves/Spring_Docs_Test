package med.voll.api.infra.security;

public record TokenDTO(String token) {

}
