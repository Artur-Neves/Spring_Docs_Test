package med.voll.api.infra.exceptions;

public class AppointmentValidationException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public AppointmentValidationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
