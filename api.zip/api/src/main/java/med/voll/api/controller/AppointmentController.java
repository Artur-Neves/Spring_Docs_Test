package med.voll.api.controller;

import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import jakarta.validation.Valid;
import med.voll.api.domain.appointment.Appointment;
import med.voll.api.domain.appointment.AppointmentDTO;
import med.voll.api.domain.appointment.AppointmentService;
import med.voll.api.domain.appointment.DetailedAppointmentDTO;

@RestController
@RequestMapping("/appointment")
public class AppointmentController {
	@Autowired
	private AppointmentService service;
	@PostMapping("/save")
	public ResponseEntity<DetailedAppointmentDTO> makeAppointment(@RequestBody @Valid AppointmentDTO dto, UriComponentsBuilder uriComponentsBuilder) {
		Appointment appointment = service.save(dto);
		URI uri = uriComponentsBuilder.path("/Appointment/{id}").buildAndExpand(appointment.getId()).toUri();
		return ResponseEntity.created(uri).body(new DetailedAppointmentDTO(appointment));
	}
}
