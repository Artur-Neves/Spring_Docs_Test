package med.voll.api.domain.appointment.Validacoes;

public interface ValidateAppointmentTest {
}
