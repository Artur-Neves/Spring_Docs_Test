package med.voll.api.domain.appointment.Validacoes;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ValidateInactiveDoctorTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
